import os
import tempfile
from pathlib import Path

import streamlit as st
from faster_whisper import WhisperModel
from meeting_ai import summarize_meeting, create_pdf

st.set_page_config(page_title="AI Meeting Summarizer", page_icon="🎙️", layout="wide")
st.title("🎙️ AI-Powered Meeting Summarizer")
st.caption("Transcribe meetings, generate structured summaries, extract decisions and action items.")

with st.sidebar:
    st.header("Settings")
    model_size = st.selectbox("Speech model", ["tiny", "base", "small"], index=1)
    language = st.text_input("Language code (blank = auto-detect)", value="")
    ollama_model = st.text_input("Ollama model", value="llama3.2")
    st.info("Run Ollama locally and pull the selected model before generating an AI summary.")

st.subheader("1. Upload meeting audio")
uploaded = st.file_uploader("Choose an audio file", type=["mp3", "wav", "m4a", "mp4", "webm", "ogg"])
if uploaded:
    st.audio(uploaded)
    if st.button("Transcribe audio", type="primary"):
        with st.spinner("Transcribing audio locally. First run may download the speech model..."):
            suffix = Path(uploaded.name).suffix or ".audio"
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(uploaded.getbuffer())
                audio_path = tmp.name
            try:
                model = WhisperModel(model_size, device="cpu", compute_type="int8")
                segments, info = model.transcribe(audio_path, language=language.strip() or None, vad_filter=True)
                transcript = "\n".join(
                    f"[{int(s.start//60):02d}:{int(s.start%60):02d}] {s.text.strip()}"
                    for s in segments
                )
                st.session_state["transcript"] = transcript
                st.success(f"Transcription complete. Detected language: {info.language}")
            except Exception as exc:
                st.error(f"Transcription failed: {exc}")
            finally:
                try: os.remove(audio_path)
                except OSError: pass

st.subheader("2. Review transcript")
transcript = st.text_area("Transcript (you can edit before summarizing)", value=st.session_state.get("transcript", ""), height=260)
if transcript.strip():
    st.session_state["transcript"] = transcript

st.subheader("3. Generate meeting intelligence")
meeting_title = st.text_input("Meeting title", value="Project Meeting")
if st.button("Generate summary", disabled=not bool(transcript.strip())):
    with st.spinner("Asking the local language model to summarize..."):
        try:
            st.session_state["result"] = summarize_meeting(transcript, meeting_title, ollama_model)
        except Exception as exc:
            st.error(str(exc))

if st.session_state.get("result"):
    result = st.session_state["result"]
    st.divider()
    st.subheader("Meeting summary")
    st.markdown(result.get("summary", ""))
    left, right = st.columns(2)
    with left:
        st.markdown("### Key decisions")
        for item in result.get("decisions", []): st.markdown(f"- {item}")
    with right:
        st.markdown("### Action items")
        for item in result.get("action_items", []): st.markdown(f"- {item}")
    st.markdown("### Topics discussed")
    for item in result.get("topics", []): st.markdown(f"- {item}")
    pdf_bytes = create_pdf(meeting_title, transcript, result)
    st.download_button("Download meeting report (PDF)", pdf_bytes,
                       file_name="meeting_summary.pdf", mime="application/pdf")
    st.caption("Review AI-generated notes before sharing. Transcription and summaries can contain errors.")

st.divider()
st.subheader("Optional: Speaker diarization")
st.write("Speaker identification is an optional extension using pyannote.audio. It requires a Hugging Face access token and acceptance of the model terms; this starter version does not claim automatic speaker labels.")
st.code("pip install pyannote.audio\n# Configure HF_TOKEN only after accepting the model terms.\n# See README.md for the optional integration notes.", language="bash")
