import json
import re
import requests
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

def _fallback_summary(transcript, title):
    lines = [x.strip() for x in transcript.splitlines() if x.strip()]
    return {
        "summary": f"Summary for **{title}**\n\n" + " ".join(lines[:5])[:1800],
        "decisions": ["No decisions were reliably extracted. Review the transcript."],
        "action_items": ["Review the transcript and assign owners and deadlines."],
        "topics": ["Meeting discussion"]
    }

def summarize_meeting(transcript, title, model="llama3.2"):
    prompt = f"""You are a careful meeting-notes assistant. Use ONLY the transcript below.
Return valid JSON with exactly these keys:
summary (string), decisions (array of strings), action_items (array of strings),
topics (array of strings). Do not invent names, owners, dates, decisions, or deadlines.
If an owner or deadline is missing, say it is not specified.
Meeting title: {title}
Transcript:
{transcript[:24000]}
"""
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": model, "prompt": prompt, "stream": False, "format": "json"},
            timeout=180
        )
        response.raise_for_status()
        raw = response.json().get("response", "{}")
        data = json.loads(raw)
        return {
            "summary": str(data.get("summary", "")),
            "decisions": data.get("decisions", []) if isinstance(data.get("decisions", []), list) else [],
            "action_items": data.get("action_items", []) if isinstance(data.get("action_items", []), list) else [],
            "topics": data.get("topics", []) if isinstance(data.get("topics", []), list) else []
        }
    except requests.exceptions.ConnectionError:
        raise RuntimeError("Cannot connect to Ollama at http://localhost:11434. Install/start Ollama and run: ollama pull llama3.2")
    except (ValueError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"The language model did not return valid JSON: {exc}")

def create_pdf(title, transcript, result):
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    y = height - 55
    pdf.setFont("Helvetica-Bold", 16); pdf.drawString(45, y, title[:75]); y -= 32
    sections = [
        ("Summary", [result.get("summary", "")]),
        ("Key decisions", result.get("decisions", [])),
        ("Action items", result.get("action_items", [])),
        ("Topics discussed", result.get("topics", [])),
        ("Transcript", transcript.splitlines()[:80])
    ]
    for heading, items in sections:
        if y < 90:
            pdf.showPage(); y = height - 55
        pdf.setFont("Helvetica-Bold", 12); pdf.drawString(45, y, heading); y -= 18
        pdf.setFont("Helvetica", 9)
        for item in items:
            text = re.sub(r"\s+", " ", str(item))
            chunks = [text[i:i+95] for i in range(0, len(text), 95)] or [""]
            for chunk in chunks:
                if y < 55:
                    pdf.showPage(); y = height - 55; pdf.setFont("Helvetica", 9)
                pdf.drawString(50, y, chunk); y -= 13
        y -= 10
    pdf.save()
    return buffer.getvalue()
