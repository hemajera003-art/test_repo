# AI-Powered Meeting Summarizer

A local-first Generative AI starter project. Upload meeting audio, transcribe it with Faster-Whisper, review/edit the transcript, generate structured meeting notes with a locally hosted Ollama LLM, and download a PDF report.

## Features
- Audio upload: MP3, WAV, M4A, MP4, WEBM, OGG
- Speech-to-text with Faster-Whisper
- Editable transcript with timestamps
- LLM-generated summary, key decisions, action items, and topics
- PDF report download
- Local inference path: audio and transcript are processed on your computer

## Requirements
- Python 3.10 or 3.11 recommended
- 8 GB RAM recommended for small/medium speech models; `tiny` or `base` is lighter
- Ollama installed locally: https://ollama.com
- Internet may be needed once to download Python packages and model weights

## Setup (Windows)
1. Install Python and Ollama.
2. Extract this ZIP.
3. Open Command Prompt in the extracted project folder.
4. Create and activate a virtual environment:

```bash
python -m venv .venv
.venv\Scripts\activate
```

5. Install packages:

```bash
pip install -r requirements.txt
```

6. Download a local LLM:

```bash
ollama pull llama3.2
```

7. Start the app:

```bash
streamlit run app/main.py
```

The app opens in your browser, usually at `http://localhost:8501`.

## Usage
1. Upload a meeting recording.
2. Choose `tiny`, `base`, or `small` speech model.
3. Click **Transcribe audio**.
4. Review and edit the transcript.
5. Enter a meeting title and click **Generate summary**.
6. Download the PDF report.

## Optional speaker identification
The included UI explains the speaker-identification extension, but this starter build does **not** automatically diarize speakers. To add it, use `pyannote.audio` with a Hugging Face account/token after accepting the relevant model terms. Then align diarization time segments with Whisper segments. Do not claim speaker labels unless that extension is implemented and tested.

## Architecture
Audio -> Faster-Whisper transcription -> editable transcript -> Ollama LLM (JSON output) -> summary / decisions / action items / topics -> PDF

## Limitations and responsible use
- AI can mishear speech or generate incomplete summaries. Always review the transcript and output.
- Names, owners, dates, and decisions must be verified by a human.
- The current version does not provide verified speaker identification.
- Do not upload confidential or personal meeting recordings without permission.
- Local processing is intended, but Ollama and Faster-Whisper may download models during setup.

## Suggested evaluation
Test at least 10 recordings with human-verified transcripts. Measure word error rate for transcription and human ratings for summary completeness, factuality, and action-item accuracy. Keep a record of failure cases.

## Project structure
```text
AI_Meeting_Summarizer/
  app/
    main.py
    meeting_ai.py
  sample_data/
  requirements.txt
  README.md
```

## License
Educational internship starter project. Add an appropriate license before public redistribution.
