import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .skills import extract_skills

def extract_experience_years(text: str):
    patterns = [
        r"(\d+(?:\.\d+)?)\s*\+?\s*years?\s+(?:of\s+)?experience",
        r"experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*years?"
    ]
    for pattern in patterns:
        match = re.search(pattern, text.lower())
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                pass
    return None

def _similarity(job_text: str, candidate_text: str) -> float:
    try:
        matrix = TfidfVectorizer(stop_words="english", ngram_range=(1, 2)).fit_transform([job_text, candidate_text])
        return float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0])
    except ValueError:
        return 0.0

def analyze_candidate(filename, text, job_description, required_skills,
                      skill_weight=0.50, similarity_weight=0.35, experience_weight=0.15):
    candidate_skills = extract_skills(text)
    job_skills = sorted(set(required_skills or extract_skills(job_description)))
    matched = sorted(set(candidate_skills) & set(job_skills))
    missing = sorted(set(job_skills) - set(candidate_skills))
    coverage = len(matched) / len(job_skills) if job_skills else 0.0
    similarity = _similarity(job_description, text)

    required_exp = extract_experience_years(job_description)
    candidate_exp = extract_experience_years(text)
    if required_exp is None or candidate_exp is None:
        exp_score = 0.5  # neutral when experience is not extractable
    elif required_exp <= 0:
        exp_score = 1.0
    else:
        exp_score = min(candidate_exp / required_exp, 1.0)

    weights_sum = skill_weight + similarity_weight + experience_weight
    if weights_sum <= 0:
        raise ValueError("At least one scoring weight must be greater than zero.")
    score = 100 * (
        skill_weight * coverage +
        similarity_weight * similarity +
        experience_weight * exp_score
    ) / weights_sum

    explanation = (
        f"Matched {len(matched)} of {len(job_skills)} identified job skills. "
        f"Text similarity: {similarity:.2f}. "
        + ("Experience could not be reliably extracted; neutral value used."
           if candidate_exp is None or required_exp is None
           else f"Parsed experience: {candidate_exp:g} years; job requirement: {required_exp:g} years.")
    )
    return {
        "filename": filename,
        "score": round(score, 2),
        "skill_coverage": round(coverage * 100, 2),
        "text_similarity": round(similarity * 100, 2),
        "experience_relevance": round(exp_score * 100, 2),
        "matched_skills": matched,
        "missing_skills": missing,
        "extracted_skills": candidate_skills,
        "experience_years": candidate_exp,
        "explanation": explanation,
    }
