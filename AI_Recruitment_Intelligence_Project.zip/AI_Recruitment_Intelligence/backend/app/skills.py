import re

# Extend this transparent dictionary for the roles you recruit for.
SKILL_ALIASES = {
    "python": ["python", "python3"],
    "java": ["java", "core java"],
    "javascript": ["javascript", "js"],
    "typescript": ["typescript", "ts"],
    "react": ["react", "react.js", "reactjs"],
    "node.js": ["node.js", "nodejs", "node js"],
    "fastapi": ["fastapi"],
    "django": ["django"],
    "flask": ["flask"],
    "sql": ["sql", "structured query language"],
    "mysql": ["mysql"],
    "postgresql": ["postgresql", "postgres"],
    "mongodb": ["mongodb", "mongo db"],
    "machine learning": ["machine learning", "ml"],
    "deep learning": ["deep learning"],
    "natural language processing": ["natural language processing", "nlp"],
    "pytorch": ["pytorch", "torch"],
    "tensorflow": ["tensorflow"],
    "scikit-learn": ["scikit-learn", "sklearn"],
    "pandas": ["pandas"],
    "numpy": ["numpy"],
    "docker": ["docker"],
    "git": ["git", "github"],
    "rest api": ["rest api", "restful api", "rest apis"],
    "aws": ["aws", "amazon web services"],
    "azure": ["azure", "microsoft azure"],
    "html": ["html", "html5"],
    "css": ["css", "css3"],
    "c++": ["c++"],
    "c#": ["c#", "c sharp"],
    "data analysis": ["data analysis", "data analytics"],
    "communication": ["communication", "stakeholder communication"],
}

def _contains_term(text: str, term: str) -> bool:
    pattern = r"(?<![a-zA-Z0-9+#])" + re.escape(term.lower()) + r"(?![a-zA-Z0-9+#])"
    return re.search(pattern, text.lower()) is not None

def extract_skills(text: str):
    found = []
    for canonical, aliases in SKILL_ALIASES.items():
        if any(_contains_term(text, alias) for alias in aliases):
            found.append(canonical)
    return sorted(found)

def normalize_required_skills(skills):
    if skills:
        return sorted({s.strip().lower() for s in skills if s.strip()})
    return extract_skills(skills_text_placeholder)  # replaced below

# Kept separate to make job-description skill extraction explicit.
skills_text_placeholder = ""
