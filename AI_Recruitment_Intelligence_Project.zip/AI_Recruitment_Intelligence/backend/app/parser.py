from pathlib import Path
import fitz

def extract_text(filename: str, content: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix == ".txt":
        return content.decode("utf-8", errors="ignore")
    if suffix == ".pdf":
        text_parts = []
        with fitz.open(stream=content, filetype="pdf") as doc:
            for page in doc:
                text_parts.append(page.get_text("text"))
        text = "\n".join(text_parts).strip()
        if not text:
            raise ValueError(f"No selectable text found in {filename}. It may be a scanned PDF; OCR is not included.")
        return text
    raise ValueError(f"Unsupported file type for {filename}. Upload PDF or TXT.")
