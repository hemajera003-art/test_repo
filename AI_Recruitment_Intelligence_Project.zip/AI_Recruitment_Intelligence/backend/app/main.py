from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from typing import List, Optional
from .parser import extract_text
from .matching import analyze_candidate
from .schemas import AnalyzeTextRequest

app = FastAPI(
    title="AI Recruitment Intelligence API",
    description="Explainable resume-to-job matching prototype. Human review is required.",
    version="1.0.0"
)

@app.get("/health")
def health():
    return {"status": "ok", "service": "AI Recruitment Intelligence API"}

@app.post("/analyze-text")
def analyze_text(payload: AnalyzeTextRequest):
    if not payload.candidates:
        raise HTTPException(status_code=400, detail="Upload at least one candidate.")
    results = []
    for candidate in payload.candidates:
        results.append(analyze_candidate(
            candidate.filename, candidate.text, payload.job_description,
            payload.required_skills,
            payload.skill_weight, payload.similarity_weight, payload.experience_weight
        ))
    results.sort(key=lambda item: item["score"], reverse=True)
    for index, item in enumerate(results, start=1):
        item["rank"] = index
    return {"count": len(results), "results": results,
            "notice": "Scores are decision-support indicators, not hiring decisions."}

@app.post("/analyze")
async def analyze(
    job_description: str = Form(...),
    files: List[UploadFile] = File(...),
    required_skills: Optional[str] = Form(None)
):
    if len(job_description.strip()) < 30:
        raise HTTPException(status_code=400, detail="Job description must contain at least 30 characters.")
    skills = [s.strip().lower() for s in (required_skills or "").split(",") if s.strip()] or None
    results = []
    for file in files:
        try:
            content = await file.read()
            text = extract_text(file.filename or "candidate.txt", content)
            if not text.strip():
                raise ValueError("No text could be extracted.")
            results.append(analyze_candidate(
                file.filename or "candidate", text, job_description, skills
            ))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"{file.filename}: {exc}") from exc
    results.sort(key=lambda item: item["score"], reverse=True)
    for index, item in enumerate(results, start=1):
        item["rank"] = index
    return {"count": len(results), "results": results,
            "notice": "Scores are decision-support indicators, not hiring decisions."}
