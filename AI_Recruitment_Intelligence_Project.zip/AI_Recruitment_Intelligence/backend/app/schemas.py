from pydantic import BaseModel, Field
from typing import List, Optional

class TextCandidate(BaseModel):
    filename: str = "candidate.txt"
    text: str

class AnalyzeTextRequest(BaseModel):
    job_description: str = Field(min_length=30)
    candidates: List[TextCandidate]
    required_skills: Optional[List[str]] = None
    skill_weight: float = Field(default=0.50, ge=0, le=1)
    similarity_weight: float = Field(default=0.35, ge=0, le=1)
    experience_weight: float = Field(default=0.15, ge=0, le=1)

class CandidateResult(BaseModel):
    filename: str
    score: float
    skill_coverage: float
    text_similarity: float
    experience_relevance: float
    matched_skills: List[str]
    missing_skills: List[str]
    extracted_skills: List[str]
    experience_years: Optional[float]
    explanation: str
