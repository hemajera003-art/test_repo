# AI-Powered Recruitment Intelligence Platform

An internship-ready, local-first application that helps recruiters compare resumes against a job description. It extracts text from PDF/TXT files, identifies skills, computes explainable matching scores, ranks candidates, and highlights skill gaps.

> This is a decision-support prototype. It must not automatically reject applicants or make employment decisions. Human review is required.

## Features
- Upload PDF or TXT resumes
- Create a job description
- Extract skills using a transparent, editable skill dictionary
- Calculate skill coverage, semantic similarity and experience relevance
- Rank candidates and show matched/missing skills
- FastAPI backend with interactive API docs
- Streamlit dashboard
- Sample resumes and a sample job description
- Unit tests and Docker setup

## Architecture
`Streamlit UI -> FastAPI -> Resume parser -> Skill extraction -> TF-IDF similarity + weighted scoring -> JSON results`

The prototype uses TF-IDF and cosine similarity so it works without paid APIs, API keys, or GPU. You can later add Sentence Transformers as an optional semantic encoder.

## Requirements
- Python 3.10+
- Internet connection for initial package installation
- 4 GB RAM minimum; 8 GB recommended

## Run locally (Windows PowerShell)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn backend.app.main:app --reload
```
Open a second terminal in the project directory:
```powershell
.venv\Scripts\Activate.ps1
streamlit run frontend/app.py
```
Open:
- Dashboard: http://localhost:8501
- API docs: http://localhost:8000/docs
- API health: http://localhost:8000/health

## Run on macOS/Linux
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.app.main:app --reload
```
Second terminal:
```bash
source .venv/bin/activate
streamlit run frontend/app.py
```

## Try the sample data
Use `data/sample_job_description.txt` and upload the three files in `data/sample_resumes/`.

## Scoring methodology
Default score:
- 50% required-skill coverage
- 35% TF-IDF text similarity
- 15% experience relevance

Weights are configurable in the API request. Scores are indicators for review, not hiring recommendations. Avoid using protected characteristics, names, photographs, age, gender, caste, religion, disability, or other sensitive attributes.

## API
- `GET /health`
- `POST /analyze` — multipart files + job description
- `POST /analyze-text` — JSON text payload

See `/docs` for schemas and try-it-out.

## Project structure
```text
AI_Recruitment_Intelligence/
├── backend/app/
│   ├── main.py
│   ├── schemas.py
│   ├── parser.py
│   ├── skills.py
│   └── matching.py
├── frontend/app.py
├── data/
├── tests/
├── requirements.txt
├── Dockerfile
└── README.md
```

## Testing
```bash
pytest -q
```

## Limitations and next steps
1. Skill extraction is dictionary-based; extend `SKILL_ALIASES` for your domain.
2. TF-IDF is lexical similarity, not a deep semantic model.
3. Experience extraction is approximate and should be manually verified.
4. Add authentication, access controls, encrypted storage and retention policies before real-world use.
5. Evaluate ranking on a labelled dataset; report Precision@K, Recall@K and NDCG.
6. Add a fairness audit and document limitations before any operational use.

## Suggested internship report chapters
1. Abstract
2. Introduction and problem statement
3. Literature review
4. Existing system and limitations
5. Proposed architecture
6. Dataset and preprocessing
7. Algorithms and scoring methodology
8. Implementation and screenshots
9. Testing and evaluation
10. Limitations, ethics and future enhancement
11. Conclusion
