# Internship Project Report
## AI-Powered Recruitment Intelligence Platform

### 1. Abstract
Describe the problem, proposed solution, methods, results and limitations.

### 2. Problem statement
Explain the manual effort involved in comparing resumes with job requirements.

### 3. Objectives
- Extract text from candidate resumes.
- Identify relevant skills.
- Compare resumes against a job description.
- Provide explainable matching indicators.

### 4. Existing system
Describe manual resume screening and its limitations. Avoid claiming the proposed tool is unbiased or fully automated.

### 5. Proposed system
Describe the parser, skill dictionary, TF-IDF vectorizer, cosine similarity and weighted scoring.

### 6. System architecture
Insert the architecture diagram from README or create a diagram based on the pipeline.

### 7. Dataset
Document the source, license, number of samples, preprocessing and synthetic/sample data limitations.

### 8. Methodology
Explain skill coverage, text similarity, experience relevance and score normalization.

### 9. Implementation
Add screenshots of upload, candidate comparison, candidate details and API documentation.

### 10. Testing and results
Report unit test results and evaluation on a manually labelled test set. Include Precision@K, Recall@K and NDCG only when computed on labelled data.

### 11. Ethical considerations
Discuss privacy, consent, fairness, human oversight, explainability and the risk of proxy discrimination.

### 12. Limitations and future work
Discuss dictionary-based extraction, TF-IDF limitations, OCR, semantic embeddings, multilingual resumes and production security.

### 13. Conclusion
Summarize what was built and what was learned.
