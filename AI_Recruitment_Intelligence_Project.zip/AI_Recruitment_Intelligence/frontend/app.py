import streamlit as st
import requests
import pandas as pd

st.set_page_config(page_title="AI Recruitment Intelligence", page_icon="🧠", layout="wide")
API_URL = st.sidebar.text_input("Backend API URL", "http://localhost:8000")

st.title("🧠 AI Recruitment Intelligence")
st.caption("Explainable resume-to-job matching | Local-first | Open-source")
st.warning("This prototype supports human review. Do not use its score as an automatic hiring or rejection decision.")

with st.sidebar:
    st.subheader("How it works")
    st.write("1. Add a job description")
    st.write("2. Upload PDF/TXT resumes")
    st.write("3. Review skill matches and gaps")
    st.write("4. Verify all extracted information manually")

job_description = st.text_area(
    "Job description",
    value="Python Developer with 2 years experience. Required skills: Python, FastAPI, Django, SQL, REST API, Git. Experience building backend applications and working with APIs.",
    height=190
)
required_skills = st.text_input("Required skills (comma-separated; optional)", "Python, FastAPI, Django, SQL, REST API, Git")
uploads = st.file_uploader("Upload resumes (PDF or TXT)", type=["pdf", "txt"], accept_multiple_files=True)

if st.button("Analyze resumes", type="primary", disabled=not uploads):
    if len(job_description.strip()) < 30:
        st.error("Please enter a job description with at least 30 characters.")
    else:
        try:
            with st.spinner("Extracting resume text and calculating matches..."):
                files = [
                    ("files", (f.name, f.getvalue(), "application/pdf" if f.name.lower().endswith(".pdf") else "text/plain"))
                    for f in uploads
                ]
                response = requests.post(
                    f"{API_URL.rstrip('/')}/analyze",
                    data={"job_description": job_description, "required_skills": required_skills},
                    files=files, timeout=120
                )
            response.raise_for_status()
            payload = response.json()
            results = payload["results"]
            st.success(f"Analyzed {len(results)} resume(s).")
            table = pd.DataFrame([{
                "Rank": r["rank"], "Candidate file": r["filename"],
                "Match score": r["score"], "Skill coverage (%)": r["skill_coverage"],
                "Text similarity (%)": r["text_similarity"]
            } for r in results])
            st.subheader("Candidate comparison")
            st.dataframe(table, use_container_width=True, hide_index=True)
            st.download_button("Download results CSV", table.to_csv(index=False), "candidate_matching_results.csv", "text/csv")
            st.subheader("Candidate-level explanations")
            for r in results:
                with st.expander(f"#{r['rank']} — {r['filename']} — {r['score']} / 100"):
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Skill coverage", f"{r['skill_coverage']}%")
                    c2.metric("Text similarity", f"{r['text_similarity']}%")
                    c3.metric("Experience relevance", f"{r['experience_relevance']}%")
                    st.write("**Matched skills:**", ", ".join(r["matched_skills"]) or "None identified")
                    st.write("**Potential skill gaps:**", ", ".join(r["missing_skills"]) or "No gaps identified by the dictionary")
                    st.write("**Extracted skills:**", ", ".join(r["extracted_skills"]) or "None identified")
                    st.caption(r["explanation"])
            st.info(payload["notice"])
        except requests.exceptions.ConnectionError:
            st.error("Cannot connect to FastAPI. Start the backend with: uvicorn backend.app.main:app --reload")
        except requests.exceptions.RequestException as exc:
            st.error(f"API error: {exc}")
        except Exception as exc:
            st.error(f"Unexpected error: {exc}")

st.divider()
st.caption("Prototype note: dictionary-based skill extraction and TF-IDF similarity are baselines. Validate and improve them with labelled data before any operational use.")
