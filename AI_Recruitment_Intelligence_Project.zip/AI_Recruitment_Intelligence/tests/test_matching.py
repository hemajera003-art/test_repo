from backend.app.matching import analyze_candidate, extract_experience_years
from backend.app.skills import extract_skills

JOB = "Python Developer with 2 years experience. Skills: Python, FastAPI, SQL, REST API, Git."

def test_extract_skills():
    skills = extract_skills("I use Python, FastAPI, SQL and Git.")
    assert "python" in skills
    assert "fastapi" in skills
    assert "sql" in skills

def test_experience_extraction():
    assert extract_experience_years("3 years experience in backend") == 3.0

def test_matching_returns_explainable_fields():
    result = analyze_candidate(
        "candidate.txt",
        "Python developer with 3 years experience. Python, FastAPI, SQL, REST API, Git.",
        JOB,
        ["python", "fastapi", "sql", "rest api", "git"]
    )
    assert 0 <= result["score"] <= 100
    assert result["skill_coverage"] == 100
    assert "missing_skills" in result
    assert "explanation" in result

def test_empty_job_skill_list_is_safe():
    result = analyze_candidate("candidate.txt", "Python developer", "A general role with responsibilities.", [])
    assert 0 <= result["score"] <= 100
